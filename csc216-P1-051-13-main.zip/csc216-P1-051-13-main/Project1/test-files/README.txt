This file contains a listing of test files in the test_files directory.

does-not-exist.txt - Missing file - is NOT in the test directory b/c it's missing
ticket1.txt - Valid ticket file
ticket2.txt - Valid file with multi line notes
ticket3.txt - Missing notes
ticket4.txt - Missing id
ticket5.txt - Missing state
ticket6.txt - Incorrect state
ticket7.txt - Missing ticket type
ticket8.txt - Incorrect ticket type
ticket9.txt - Missing subject
ticket10.txt - Missing caller
ticket11.txt - Missing category
ticket12.txt - Incorrect category
ticket13.txt - Missing priority
ticket14.txt - Incorrect priority
ticket15.txt - Missing owner in Working state
ticket16.txt - Feedback code when not feedback state
ticket17.txt - Resolution code when not Resolved or Closed state
ticket18.txt - Cancellation code when not Canceled state
ticket19.txt - Resolution code inappropriate for Request ticket type
ticket20.txt - Resolution code inappropriate for Incident ticket type